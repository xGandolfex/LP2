﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PConsumo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] Consumo = new double[5, 4];
            string aux = "";
            string[] Nomes = { "Produção", "Escritório", "Refeitório", "Limpeza", "logística" };
            double[] ConsumoSem = new double[5];
            double Total = 0;

            for (int setor = 0; setor < 5; setor++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    aux = Interaction.InputBox($"Digite o consumo do setor {Nomes[setor]} da semana {semana + 1}", "Entrada de Dados");
                    if (!double.TryParse(aux, out Consumo[setor, semana]) || Consumo[setor, semana] < 0)
                    {
                        MessageBox.Show("Valor digitado incorreto");
                        semana--;
                    }
                    if (aux == "")
                    {
                        return;
                    }
                    ConsumoSem[setor] += Consumo[setor, semana];
                }
                lstbxDados.Items.Add($"{Nomes[setor]} {ConsumoSem[setor]}L -> {ConsumoSem[setor] * 0.01:C2}");
                Total += ConsumoSem[setor];

            }

            lstbxDados.Items.Add("---------------------------");
            lstbxDados.Items.Add($"Total Geral {Total}L -> {Total * 0.01:C2}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxDados.Items.Clear();   
        }
    }
    
}
